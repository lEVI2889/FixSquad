# Integration Contract: System Infrastructure & Auth (Week 1)

**AUTHOR:** Shan
**BRANCH:** `feature/auth-infra`

> This documents what I built in Week 1 so the rest of the team (and your AI agents) can integrate against it. Not for Git — see `.gitignore`.

---

## 1. Server & Database

- Express app entry point: `server.js`
- Raw MySQL pool (mysql2/promise, no ORM): `db.js`
- All routes should be mounted in `server.js` on the shared `app` instance.

### `users` Table (fulfills Rohan's contract, Section 1)

```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

`id` is `INT PRIMARY KEY` — safe to use as the target of `services.provider_id (INT, FK -> users.id)`.

Run `sql/schema.sql` against your local MySQL instance before starting the server.

---

## 2. Auth Middleware

File: `middleware/authMiddleware.js`, exported as `protect`.

- Reads a JWT from the `Authorization: Bearer <token>` header.
- On success, attaches **`req.user.id`** to the request — exactly the field name Rohan's contract requires for `provider_id`.
- On failure, responds `401` with `{ "success": false, "message": "..." }` and does not call `next()`.

**To protect any route (e.g. Rohan's `/api/services`):**
```javascript
const { protect } = require('../middleware/authMiddleware');
app.use('/api/services', protect, serviceRoutes);
```

---

## 3. API Endpoints

Base path: `/api/auth`

### POST `/api/auth/register`
**Auth:** None

Request body:
```json
{
  "name": "Jane Doe",
  "email": "jane@example.com",
  "password": "plaintext_password"
}
```

Response `201`:
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "id": 1,
    "name": "Jane Doe",
    "email": "jane@example.com",
    "token": "eyJhbGciOi..."
  }
}
```

Errors: `400` (missing fields), `409` (email already registered), `500` (server error).

### POST `/api/auth/login`
**Auth:** None

Request body:
```json
{
  "email": "jane@example.com",
  "password": "plaintext_password"
}
```

Response `200`:
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "id": 1,
    "name": "Jane Doe",
    "email": "jane@example.com",
    "token": "eyJhbGciOi..."
  }
}
```

Errors: `400` (missing fields), `401` (invalid credentials), `500` (server error).

---

## 4. Session / Token Details

- Auth is **stateless JWT**, not server-side sessions.
- Token payload: `{ "id": <user.id>, "iat": ..., "exp": ... }`
- Expiry: 7 days.
- Env var `JWT_SECRET` must be set (see `.env.example`) and must be the **same value** across everyone's local `.env` if you want tokens to validate consistently in shared testing — otherwise each person's server can only verify tokens it issued itself.
- Frontend must send the token on every protected request as:
  `Authorization: Bearer <token>`

---

## 5. What's Still Needed From Others

- Rohan: `routes/serviceRoutes.js` mounted per his contract, using `req.user.id` and the `protect` middleware above.
- Wasik: `categories` table (`id INT PRIMARY KEY`, `name VARCHAR`).
- Naim: wire `ProviderPortfolio.jsx` into the router; point the frontend's `api.js` base URL at wherever this backend is hosted (or a dev proxy to avoid hardcoded ports).
